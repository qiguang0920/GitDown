<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>Document</title>
<?php $this->load->view(MODULE .'/common/head')?>
</head>

<body>
<div class="container">
    <div id="here_location">当前位置：系统管理<span>&gt;</span>IP归属地查询</div>
    <div id="forms">
        <div class="box">
            <div class="box_border">
                <div class="box_center">
                    <form action="<?php echo site_url(MODULE .'/'. C .'/'. M) ?>" class="jqtransform" method="post">
                        <table class="form_table pt15 pb15" width="100%" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td class="td_right">请输入IP或域名：</td>
				<td><input type="text" name="ip" class="input-text lh30" value="" /></td>
                              
                            </tr>
                            <tr>
                                <td class="td_right">IP归属地：</td>
											
				<td>您查询的IP是:<?php echo $check_ip ?><br><?php echo $country ?><br><?php echo $area ?></td>
                               
                            </tr>
                          
                          
                            <tr>
                                <td class="td_right">&nbsp;</td>
                                <td><input type="submit" name="button2" class="btn btn82 btn_save2" value="查询">
                                    <input type="reset" name="button2" class="btn btn82 btn_res" value="重置"></td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
