<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ip extends Admin_Controller {
	public function index(){
		$data = array();
		$this->load->library('iplocation');

		if (!empty($_POST)){
		$ip = $this->input->post('ip');
		$array= $this->iplocation->getlocation($ip);
		$data['check_ip'] = $array['ip'];
		$data['country'] = $array['country'];
		$data['area'] = $array['area'];
		} else {
			$data['country']='';
			$data['area']='';
			$data['check_ip']='';
		}
				
		$this->load->view(MODULE .'/'. C . '/'. M,$data);
	}
}	
